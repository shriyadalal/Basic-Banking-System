<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Basic Banking System</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>  
    <footer id="footer">
        COPYRIGHT &copy; 2021 THE SPARKS BANKING  |    All Rights Reserved. <br>
        THE SPARKS BANKING Created by SHRIYA DALAL Powered by THE SPARKS FOUNDATION
    </footer>
</body>
</html>
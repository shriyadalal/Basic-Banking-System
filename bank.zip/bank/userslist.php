<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Users</title>
    <link rel="stylesheet" href="css/table.css">
    <link rel="stylesheet" href="css/createuser.css">
    <link rel="stylesheet" href="css/style.css">

      <style>
    section{
        background-image: url(img/download.jpg);
        height: 100%;
        width: 100%;
        padding: 100px;
    }
    .col{
        margin: 20px;
        padding: 4px 12px;
        font-size: 30px;
    }
</style>
</head>


<body>
<section>
<?php
    include 'config.php';
    $sql = "SELECT * FROM users";
    $result = mysqli_query($conn,$sql);
?>

<?php
  include 'navbar.php';
?>

<div class="container"> <br>
        <h2 class="text-center pt-4">Users List:</h2> <br> <hr>
        <br>
            <div class="row">
                <div class="col">
                    <div class="table-responsive-sm">
                    <table class="content-table">
                        <thead>
                            <tr>
                            <th scope="col" class="text-center py-2">Id</th>
                            <th scope="col" class="text-center py-2">Name</th>
                            <th scope="col" class="text-center py-2">E-Mail</th>
                            <th scope="col" class="text-center py-2">Credit</th>
                            <th scope="col" class="text-center py-2">Operation</th>
                            </tr>
                        </thead> 
                        <tbody>
                <?php 
                    while($rows=mysqli_fetch_assoc($result)){
                ?>
                    <tr>
                        <td class="py-2"><?php echo $rows['id'] ?></td>
                        <td class="py-2"><?php echo $rows['name']?></td>
                        <td class="py-2"><?php echo $rows['email']?></td>
                        <td class="py-2"><?php echo $rows['balance']?></td>
                        <td><a href="transaction.php?id= <?php echo $rows['id'] ;?>"> <button type="button" class="btn">Transact</button></a></td> 
                    </tr>
                <?php
                    }
                ?>
            
                        </tbody>
                    </table>
                    </div>
                </div>
            </div> 
         </div></section>
         <?php
         include 'footer.php';
         ?>
</body>
</html>
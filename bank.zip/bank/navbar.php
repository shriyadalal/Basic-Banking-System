<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Basic Banking System</title>
    <link rel="stylesheet" href="css/table.css">
    <link rel="stylesheet" href="css/createuser.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <header>
        <a href="index.php#Home#Home" id="logo" class="logo">SPARKS BANKING</a>
        <div id="toggle"></div>
        <ul>
            <img src="img/home-icon.png"/><li><a href="index.php#Home">Home</a></li>
            <img src="img/service-icon.png"/><li><a href="index.php#Services">Services</a></li>
            <img src="img/feature-icon.png"/><li><a href="index.php#Features">Features</a></li>
            <img src="img/about-icon.png"/><li><a href="index.php#About">About</a></li>

        </ul>
    </header>
    <script>
        window.addEventListener('scroll', function () {
            var header = document.querySelector('header');
            header.classList.toggle('sticky', window.scrollY > 0)
        });

    </script>
</body>
</html>